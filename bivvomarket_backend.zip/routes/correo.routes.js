const express = require("express");
const router = express.Router();
const { enviarCorreo } = require("../controllers/correo.controller.js");
const authMiddleware = require("../middlewares/auth.middleware.js");


// 🔒 Rutas protegidas con token
router.post("/", authMiddleware, enviarCorreo); // Enviar correo

module.exports = router;